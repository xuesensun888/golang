#!/bin/bash 
GT_BASEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ ! -f "${GT_BASEDIR}/gettopic.sh." ]; then
  OB_BASEDIR="$(grep -E  '[e|E]xec' /usr/share/applications/*ettopic.desktop|head -n 1 |grep -oE '\s[a-z\/]+\.sh')"
fi
export GT_BASHDIR
cd "${GT_BASEDIR}" || exit 1
source ${GT_BASEDIR}/tasks/public.sh

############################################################################


read -er -p "请输入车辆ID: " num
if [ "$num" -gt 100 ] && [ $((num % 2)) -ne 0 ];then 
    acu_ip=100.100.99.$num
    
else 
    acu_ip=100.100.100.$num


fi

if ( timeout 5 ping -c 1 $acu_ip > /dev/null )
then 
    GT_echo "green" "车辆网络正常"
else
    GT_echo "red" "车辆无网络连接，请检查网络"
    exit
fi
printf "\n"

if [ ${#num} -eq 1 ];then
    car_num=1000${num}
elif [ ${#num} -eq 2 ];then 
    car_num=100${num}
else 
    car_num=10${num} 
fi

function ask_password(){
    while true 
    do 
        GT_echo "green" "请输入密码: \n"
        read -sr SUDOPASSWORD
        sudo -k
        if (timeout 3 sshpass -p "${SUDOPASSWORD}" ssh -t -q -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" cargo@"$acu_ip"  "ls" >/dev/null 2>&1)
        then 
            break  
        else 
            GT_echo "red" "密码错误 \n" 
            continue
        fi
    done  
}
ask_password
# prompt_team
# sleep 20
if ! delect_host;then 
    GT_echo "red" "获取本地运行环境失败,请按任意键退出 ErrCode:13\n"
    read -ern 1 
    exit 20;
fi 
if ! delect_team;then 
    GT_echo "red" "获取组队配置失败,按任意键退出 ErrCode:14\n"
    read -ern 1 
    exit 20;
fi
 delect_mount
 delect_pad
 
 while true 
do  
    # if [ "${OB_RUNTIME_MACHINE}" == "ORIN_single" ];then 
    #     prompt_front
    # elif [ "${OB_RUNTIME_MACHINE}" == "ORIN_C" ];then 
    #     prompt_orin_c
    # fi
    prompt
    read -er option
    [ "${option}" == $'\x0a' ] && continue
    case ${option} in 
    1) 
        start_time=$(date +"%s")
        getTopic
        echo $orin_2
        ret=$?
    ;;
    2) showmenu(){
        while true;do
        clear 
        echo "1. 下载jpg文件"
        echo "2. 生成jpg文件"
        echo "3. 返回上一级"
        echo "4. 退出"
        read -er -p "请输入序号操作 " n
        case ${n} in 
        1)
            start_time=$(date +"%s")
            download_pic
            ret=$?
        ;;
        2)
            start_time=$(date +"%s")
            create_jpg
            ret=$?  
        ;;
        3)
            return
            ret=$?
        ;;
        4)
            exit 0 
        ;;
        *)
            echo "无效选择，请选择 1-4 之间的数字。"
        esac
        if [ ! "${ret}" == 0 ];then
         err_msg=". ErrCode: ${ret}"
        [[ ! "${ret}" =~ ^[0-9]+$ ]] && err_msg=": ${ret}"
        GT_echo "red" "执行失败${err_msg}\n"
          fi
        stop_time=$(date +"%s")
         GT_echo "=== 消耗时间: "$((stop_time - start_time))" S ===\n"

        read -ern 1 -p "按任意键继续..."
        done
    }
        start_time=$(date +"%s")
        showmenu
        ret=$?
    ;;
    
    3)
        
         start_time=$(date +"%s")
        bash $GT_BASEDIR/tasks/get_lidar.sh
        ret=$?
    ;;
    4)
        exit 0
       
    esac
    if [ ! "${ret}" == 0 ]
    then
         err_msg=". ErrCode: ${ret}"
    [[ ! "${ret}" =~ ^[0-9]+$ ]] && err_msg=": ${ret}"
    GT_echo "red" "执行失败${err_msg}\n"
    fi
  stop_time=$(date +"%s")
  GT_echo "=== 消耗时间: "$((stop_time - start_time))" S ===\n"

    read -ern 1 -p "按任意键继续..."

done