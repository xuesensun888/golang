#!/bin/bash 

msg=$(sshpass -p "cargo1e9" ssh -t -q -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" cargo@100.100.100.62 "cat /opt/cargo/lidar/self_check/result.log")
# printf "%s\n" "$msg"
check_result=$(echo "$msg" | grep "check_result" | awk '{print $2}'|tr -d '\r')
if [ "$check_result" == "OK" ];then 
    echo "check_result is ok,lidar is problem"
    exit 0 
fi
#如果check_result是NG,检查各个模块的状态
if [ "$check_result" == "NG" ];then 
    #逐行读取
    while read -r line;do
        #检查每行是否包含result:ng
        # if echo "$line" | grep -q "result: NG";then
            #获取模块名称
            echo "$line"
    done < <(echo "$msg" |grep -A 2 -E 'LidarFM|LidarLF|LidarLR|LidarRF|LidarRM|LidarRR' )

fi

